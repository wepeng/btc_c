<?php
set_time_limit(0);
//start 
//bitcoin-qt.exe -server -rest -rpcbind=127.0.0.1  -rpcuser=RPCuser -rpcpassword=RPCpasswd

/**
* 通过WIF格式的私钥获取256位的私钥（字符串的二进制表示）
*/
function getBTCKey($wif)
{
	//BTC的base58序列
	$btc = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
	
	$bi = strval(0);
	$len = strlen($wif);
	$leadingZerosNum = 0;
	for($i=$len-1; $i>=0; $i--)
	{
		$alphaIndex = strpos($btc, $wif[$i]);
		if ($alphaIndex < 0) {
			echo 'Error!';
			exit;
		}
		$bi = bcadd($bi, bcmul(strval($alphaIndex), bcpow(58,$len - 1 - $i)));
		if($wif[$i]==='1')
		{
			$leadingZerosNum++;
		} else {
			$leadingZerosNum = 0;
		}
	}
	
	//十进制转十六进制
	$res = '';
	while($bi != strval(0))
	{
		$res = dechex(bcmod($bi, '16')).$res;
		$bi = bcdiv($bi, '16');
		echo $bi.'<br/>';
	}
	
	//$res = tenTOtwo($bi);
	
	//添加前导0
	echo $res.'<br/>'.$leadingZerosNum.'<br/>';
	while($leadingZerosNum-- >0)
	{
		$ss = '0'.$ss;
	}
	//echo $res.'<hr/>';exit;
	$res = substr($res, 2, 64);
	return $res;
}

require_once('easybitcoin.php');
$bitcoin = new Bitcoin('RPCuser','RPCpasswd');
//插入数据库
$db = new mysqli('localhost', 'root', 'root', 'btc');

for($i=0; $i<100; $i++)
{
	$btc = $bitcoin->getnewaddress();

	print_r($btc);
	echo '<br/>';
	$key_wif = $bitcoin->dumpprivkey($btc);
	print_r($key_wif);
	echo '<br/>';
	echo $key_hex = getBTCKey($key_wif);
	echo '<hr/>';

	$query = "INSERT INTO `btc` (`key_hex`, `key_wif`,`btc`) VALUES ('$key_hex', '$key_wif', '$btc')";
	$result = $db->query($query);
}
$db->close();  //关闭一个数据库连接，这不是必要的，因为脚本执行完毕时会自动关闭连接
exit;




//十进制转二进制
function tenTOtwo($str)
{
	$res = '';
	$i = 0;
	while($str != strval(0))
	{
		$res = bcmod($str, '2').$res;
		$str = bcdiv($str, '2');
		//echo $str.'<br/>';
		$i = $i + 1;
		//echo '<br/>';
		if($i >= 8)
		{
			$res = ','.$res;
			$i = 0;
		}
	}
	return $res;
}

function strToassci($ss)
{
	for($i=0; $i<strlen($ss); $i++)
	{
		echo ord($ss[$i]);
		echo ".";
	}
}

//字符串转二进制
function strTobin($string){ 
    $hex="";
    for($i=0;$i<strlen($string);$i++){
        $hex.=decbin(ord($string[$i])).' , ';
    }
    $hex=strtoupper($hex);
    return $hex;
}



$btc = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

$str = 'L16BXB1ZkwXdGmaMSr3FQBBTbnjJ79DNYRRBCVLRGLKgcwYcZVE2';

//$str = "5Hue";

$bi = strval(0);
$len = strlen($str);
//echo "STR:".strTobin($str).'<hr/>';
$leadingZerosNum = 0;
for($i=$len-1; $i>=0; $i--)
{
	$alphaIndex = strpos($btc, $str[$i]);
	if ($alphaIndex < 0) {
		echo 'Error!';
		exit;
	}
	//echo $i."==".$alphaIndex.":";
	//echo $bi = $bi + $alphaIndex*(pow($len - 1 - $i,58));
	$bi = bcadd($bi, bcmul(strval($alphaIndex), bcpow(58,$len - 1 - $i)));
	//echo strTobin(strval($alphaIndex)).'<br/>';
	//echo strTobin(bcmul(strval($alphaIndex), bcpow(58,$len - 1 - $i))).'<hr/>';
	//echo $bi.'<hr/>';
	if($str[$i]=='1')
	{
		$leadingZerosNum++;
	} else {
		$leadingZerosNum = 0;
	}
	//echo 'leadingZerosNum:'.$leadingZerosNum.'<hr/>';
}
echo strlen($bi);
echo "<hr/>";



$ss = tenTOtwo($bi);
$ss = substr($ss, 1);  //删除第一个，
echo $ss.'=====<hr/>';

//添加前导0
while($leadingZerosNum-- >0)
{
	$ss = '00000000,'.$ss;
}
echo $ss.'=====<hr/>';

$ss = explode(',', $ss);
unset($ss[0]);
unset($ss[33]);
unset($ss[34]);
unset($ss[35]);
unset($ss[36]);
unset($ss[37]);
//var_dump($ss);

//合并
$ss = implode('', $ss);
echo strlen($ss);

/*
function base58_decode($input)
{
    $alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    $base_count = strval(strlen($alphabet));
    $decoded = strval(0);
    $multi = strval(1);
    while (strlen($input) > 0)
    {
        $digit = substr($input, strlen($input) - 1);
        $decoded = bcadd($decoded, bcmul($multi, strval(strpos($alphabet, $digit))));
        $multi = bcmul($multi, $base_count);
        $input = substr($input, 0, strlen($input) - 1);
    }
    return($decoded);
}

$str = base58_decode($str);
*/
/*
$res = '';
while(bcmod('16', $str) != 0)
{
	echo $str."<br/>";
	$res .= bcmod($str, '16').",";
	$str = bcdiv($str, '16');
}
echo $str."<br/><hr/>";
echo $res;
*/

